﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Persistencia
{
    internal class Conexion
    {
        internal const string _Cnn = "Data Source= .; Initial Catalog =  ProyectoFinalBios; Integrated Security = true"; // hay que cambiar el data source a '.' para que ande en bios
    }
}
